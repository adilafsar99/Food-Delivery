// To control access rights

firebase.auth().onAuthStateChanged((user) => {
    if (user) {
      firebase.database().ref(`users/${user.uid}`).once("value", (user) => {
        if (user.val().role === "res-owner") {
            window.location = "restaurant.html";
        } else {
          window.location = "../index.html";
        }
      });
    }
  });
  
  // To validate user input
  
  let validate = () => {
    let inputs = document.querySelectorAll(".form-floating input");
    let messageDiv = document.getElementById("error-message");
    let regex;
    for (let i = 0; i < inputs.length; i++) {
      if (inputs[i].name === "email") {
        regex = /^((?!\.)[\w-_.]*[^.])(@\w+)(\.\w+(\.\w+)?[^.\W])$/gm;
      } else if (inputs[i].name === "password") {
        regex = /^((?=\S*?[a-zA-Z])(?=\S*?[0-9]).{6,})\S$/;
      }
      if (!regex.test(inputs[i].value)) {
        inputs[i].style.borderColor = "#da5b6d";
        inputs[i].style.backgroundColor = "#ff8a80";
        if (inputs[i].name === "email") {
          messageDiv.innerHTML = "Invalid email!";
        } else if (inputs[i].name === "password") {
          messageDiv.innerHTML = "Invalid password!";
        }
        messageDiv.classList.add("d-block");
        messageDiv.classList.remove("d-none");
        return false;
      }
      messageDiv.classList.remove("d-block");
      messageDiv.classList.add("d-none");
      inputs[i].style.borderColor = "#53a655";
      inputs[i].style.backgroundColor = "#baff80";
    }
    return true;
  };
  
  // To login user
  
  let login = () => {
    let isValid = validate();
    if (isValid) {
      let inputs = document.querySelectorAll(".form-floating input");
      let messageDiv = document.getElementById("error-message");
      let email = inputs[0];
      let password = inputs[1];
      firebase.auth().signInWithEmailAndPassword(email.value, password.value)
      .then((res) => {
        firebase.database().ref(`users/${res.user.uid}`).once("value", (user) => {
          let messageDiv = document.getElementById("success-message");
          messageDiv.innerHTML = "Log in successful!";
          messageDiv.classList.add("d-block");
          messageDiv.classList.remove("d-none");
          if (user.val().role === "user") {
            setTimeout(() => {
              window.location = "profile.html";
            }, 1500);
          } else {
            setTimeout(() => {
              window.location = "admin.html";
            }, 1500);
          }
        });
      })
      .catch((err) => {
          if (err.message.indexOf("email") !== -1) {
            email.style.borderColor = "#da5b6d";
            email.style.backgroundColor = "#ff8a80";
            messageDiv.innerHTML = "Email already in use!";
          }
          else {
            password.style.borderColor = "#da5b6d";
            password.style.backgroundColor = "#ff8a80";
            messageDiv.innerHTML = "Invalid Passsword!";
          }
      })
    }
  };