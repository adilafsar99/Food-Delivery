let resId = window.location.hash.slice(1);
firebase.database().ref(`users/${resId}/dishes`).on("child_added", (res) => {
    let dishCards = document.getElementById("dishes-cards");
   dishCards.innerHTML += `<div class="card" style="width: 18rem;">
   <img src="${res.val().image}" class="card-img-top">
   <div class="card-body">
     <h5 class="card-title">Dish Name: ${res.val().name}</h5>
   </div>
   <ul class="list-group list-group-flush">
     <li class="list-group-item">Price: ${res.val().price} Rs</li>
     <li class="list-group-item">Delivery: ${res.val().deliveryType}</li>
     <li class="list-group-item">Category: ${res.val().category}</li>
   </ul>
   <div class="card-body">
     <a href="#" class="card-link" onclick="placeOrder('${res.key}', '${resId}')">Order</a>
   </div>
 </div>`;
})

let placeOrder = (dishId, resId) => {
  firebase.database().ref(`orders/${resId}`).push({dish: dishId}).then(() => {
      alert("Order Placed Successfully!");
  })
}