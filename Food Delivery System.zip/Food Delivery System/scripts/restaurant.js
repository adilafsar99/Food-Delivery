let openTab = (evt, tabName) => {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
};

// To upload image to Firebase Storage and retrieve a URL

let uploadImage = (file) => {
  return new Promise((resolve, reject) => {
    var storageRef = firebase.storage().ref();
    // Upload file and metadata to storage
    var uploadTask = storageRef.child("profilePic/" + file.name).put(file);

    // Listen for state changes, errors, and completion of the upload.
    uploadTask.on(
      firebase.storage.TaskEvent.STATE_CHANGED,
      // or 'state_changed'
      (snapshot) => {
        // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
        var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log("Upload is " + progress + "% done");
        switch (snapshot.state) {
          case firebase.storage.TaskState.PAUSED: // or 'paused'
            console.log("Upload is paused");
            break;
          case firebase.storage.TaskState.RUNNING: // or 'running'
            console.log("Upload is running");
            break;
        }
      },
      (error) => {
        // A full list of error codes is available at
        // https://firebase.google.com/docs/storage/web/handle-errors
        switch (error.code) {
          case "storage/unauthorized":
            // User doesn't have permission to access the object
            break;
          case "storage/canceled":
            // User canceled the upload
            break;

          // ...

          case "storage/unknown":
            // Unknown error occurred, inspect error.serverResponse
            break;
        }
      },
      () => {
        // Upload completed successfully, now we can get the download URL
        uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
          resolve(downloadURL);
        });
      }
    );
  });
};

let addDish = async () => {
  let name = document.getElementById("name");
  let price = document.getElementById("price");
  let category = document.getElementById("category");
  let deliveryType = document.getElementById("delivery-type");
  let image = document.getElementById("image");
  if (name.value.length === 0) {
    name.style.borderColor = "#da5b6d";
    name.style.backgroundColor = "#ff8a80";
    let messageDiv = document.getElementById("error-message");
    messageDiv.innerHTML = "Invalid name!";
    messageDiv.classList.add("d-block");
    messageDiv.classList.remove("d-none");
  } else if (price.value.length === 0) {
    price.style.borderColor = "#da5b6d";
    price.style.backgroundColor = "#ff8a80";
    let messageDiv = document.getElementById("error-message");
    messageDiv.innerHTML = "Invalid price!";
    messageDiv.classList.add("d-block");
    messageDiv.classList.remove("d-none");
  } else if (image.files.length === 0) {
    image.style.borderColor = "#da5b6d";
    image.style.backgroundColor = "#ff8a80";
    let messageDiv = document.getElementById("error-message");
    messageDiv.innerHTML = "Invalid name";
    messageDiv.classList.add("d-block");
    messageDiv.classList.remove("d-none");
  } else {
    let messageDiv = document.getElementById("error-message");
    messageDiv.classList.remove("d-block");
    messageDiv.classList.add("d-none");
    image = await uploadImage(image.files[0]);
    let product = {
      name: name.value,
      price: price.value,
      category: category.value,
      deliveryType: deliveryType.value,
      image: image,
    };
    firebase.auth().onAuthStateChanged((user) => {
      firebase.database().ref(`users/${user.uid}/dishes`).push(product);
    });
  }
};

firebase.auth().onAuthStateChanged((user) => {
    firebase.database().ref(`orders/${user.uid}`).on("child_added", (res) => {
        
    })
})

let logOut = () => {
  firebase
    .auth()
    .signOut()
    .then(() => {
      window.location = "../index.html";
    });
};
