// To control access rights

/*firebase.auth().onAuthStateChanged((user) => {
    if (user) {
      firebase.database().ref(`users/${user.uid}`).once("value", (user) => {
        if (user.val().role === "res-owner") {
          window.location = "restaurant.html";
        } else {
          window.location = "../index.html";
        }
      });
    }
  })*/

  
  // User class to create User objects
  
  class User {
    constructor(username, email, phone, country, city, password, image, role) {
      this.username = username;
      this.email = email;
      this.phone = phone;
      this.country = country;
      this.city = city;
      this.password = password;
      this.image = image;
      this.role = role;
    }
  }
  
  // To upload image to Firebase Storage and retrieve a URL
  
  let uploadImage = (file) => {
    return new Promise((resolve,
      reject) => {
      var storageRef = firebase.storage().ref();
      // Upload file and metadata to storage
      var uploadTask = storageRef.child('profilePic/' + file.name).put(file);
  
      // Listen for state changes, errors, and completion of the upload.
      uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED,
        // or 'state_changed'
        (snapshot) => {
          // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
          var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log('Upload is ' + progress + '% done');
          switch (snapshot.state) {
            case firebase.storage.TaskState.PAUSED: // or 'paused'
              console.log('Upload is paused');
              break;
            case firebase.storage.TaskState.RUNNING: // or 'running'
              console.log('Upload is running');
              break;
          }
        },
        (error) => {
          // A full list of error codes is available at
          // https://firebase.google.com/docs/storage/web/handle-errors
          switch (error.code) {
            case 'storage/unauthorized':
              // User doesn't have permission to access the object
              break;
            case 'storage/canceled':
              // User canceled the upload
              break;
  
            // ...
  
            case 'storage/unknown':
              // Unknown error occurred, inspect error.serverResponse
              break;
          }
        },
        () => {
          // Upload completed successfully, now we can get the download URL
          uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
            resolve(downloadURL);
        });
      }
    );
    });
  };
  
  // To validate user input
  
  let validate = () => {
  let inputs = document.querySelectorAll("input");
  let messageDiv = document.getElementById("error-message");
  let invalidInput = false;
  let regex;
  for (let i = 0; i < inputs.length; i++) {
  if (inputs[i].id === "username") {
  regex = /^(?=.{3,30}$)[a-z]+(?:['_.\s][a-z]+)*$/gim;
  } else if (inputs[i].id === "email") {
  regex = /^((?!\.)[\w-_.]*[^.])(@\w+)(\.\w+(\.\w+)?[^.\W])$/gm;
  }
  else if (inputs[i].id === "country") {
  regex = /^(?=.{3,30}$)[a-z]+(?:['_.\s][a-z]+)*$/gim;
  } else if (inputs[i].id === "city") {
  regex = /^(?=.{3,30}$)[a-z]+(?:['_.\s][a-z]+)*$/gim;
  }
  else if (inputs[i].id === "password") {
    regex = /^((?=\S*?[a-zA-Z])(?=\S*?[0-9]).{6,})\S$/;
  }
  if (inputs[i].id !== "phone" && inputs[i].id !== "repeat-password" && inputs[i].id !== "res-image" && !regex.test(inputs[i].value)) {
   invalidInput = true;
  }
  else if (inputs[i].id === "phone") {
      if (inputs[i].value.length !== 11) {
        invalidInput = true;
      }
  } else if (inputs[i].id === "repeat-password") {
  if (inputs[i-1].value !== inputs[i].value) {
  invalidInput = true;
  }
  } else if (inputs[i].id === "res-image") {
  if (inputs[i].files.length === 0) {
  invalidInput = true;
  } else if (inputs[i].files[0].type.indexOf("image") === -1) {
  invalidInput = true;
  }
  }
  if (invalidInput) {
  inputs[i].style.borderColor = "#da5b6d";
  inputs[i].style.backgroundColor = "#ff8a80";
  if (inputs[i].id === "username") {
  messageDiv.innerHTML = "Invalid username!";
  } else if (inputs[i].id === "email") {
  messageDiv.innerHTML = "Invalid email!";
  } 
  else if (inputs[i].id === "phone") {
    messageDiv.innerHTML = "Invalid phone number!";
    }
  else if (inputs[i].id === "country") {
  messageDiv.innerHTML = "Invalid country name!";
  } else if (inputs[i].id === "city") {
  messageDiv.innerHTML = "Invalid city name!";
  } 
  else if (inputs[i].id === "password") {
    messageDiv.innerHTML = "Invalid password!";
  }
  else if (inputs[i].id === "repeat-password") {
  messageDiv.innerHTML = "Password doesn't match!";
  } else {
  messageDiv.innerHTML = "You didn't provide a profile picture!";
  }
  messageDiv.classList.add("d-block");
  messageDiv.classList.remove("d-none");
  return false;
  }
  messageDiv.classList.remove("d-block");
  messageDiv.classList.add("d-none");
  inputs[i].style.borderColor = "#53a655";
  inputs[i].style.backgroundColor = "#baff80";
  }
  return true;
  };
  
  // To register user
  
  let register = async () => {
  let isValid = validate();
  if (!isValid) {
  return;
  } else {
  let inputs = document.querySelectorAll("input");
  let username = inputs[0];
  let email = inputs[1];
  let phone = inputs[2]
  let country = inputs[3];
  let city = inputs[4];
  let password = inputs[5];
  let file = inputs[7];
  let imageURL = await uploadImage(file.files[0]);
  let role = "user";
  firebase.auth().createUserWithEmailAndPassword(email.value, password.value)
  .then((res) => {
    let userObj = new User(username.value, email.value, phone.value, country.value, city.value, password.value, imageURL, role);
  firebase.database().ref(`users/${res.user.uid}`).set(userObj)
  .then(() => {
    let messageDiv = document.getElementById("success-message");
    messageDiv.innerHTML = "Sign up successful!";
    messageDiv.classList.add("d-block");
    messageDiv.classList.remove("d-none");
    setTimeout(() => {
    window.location = "login.html";
    }, 1500);
    })
  })
  .catch((err) => {
  if (err.message.indexOf("email") !== -1) {
       let email = document.getElementById("email");
       let messageDiv = document.getElementById("error-message");
          email.style.borderColor = "#da5b6d";
  email.style.backgroundColor = "#ff8a80";
  messageDiv.innerHTML = "This email is already in use by another account!";
  messageDiv.classList.add("d-block");
  messageDiv.classList.remove("d-none");
  }
  });
  }
  };