firebase.auth().onAuthStateChanged((user) => {
  if (user) {
    firebase
      .database()
      .ref(`users/${user.uid}`)
      .once("value", (res) => {
        if (res.val().role === "res-owner") {
          window.location = "pages/restaurant.html";
        }
        let signupLink = document.getElementById("signup-link");
        let loginLink = document.getElementById("login-link");
        let logoutLink = document.getElementById("logout-link");
        console.log(logoutLink);
        signupLink.classList.add("d-none");
        loginLink.classList.add("d-none");
        logoutLink.classList.remove("d-none");
        if (res.val().role === "res-owner") {
          let resLink = document.getElementById("res-link");
          resLink.classList.remove("d-none");
        }
      });
  }
});

let logOut = () => {
  firebase
    .auth()
    .signOut()
    .then(() => {
      let signupLink = document.getElementById("signup-link");
      let loginLink = document.getElementById("login-link");
      let logoutLink = document.getElementById("logout-link");
      signupLink.classList.remove("d-none");
      loginLink.classList.remove("d-none");
      logoutLink.classList.add("d-none");
    });
};

firebase
  .database()
  .ref(`users`)
  .on("child_added", (res) => {
    if (res.val().role === "res-owner") {
      let resCardsDiv = document.getElementById("restaurant-cards");
      resCardsDiv.innerHTML += `<div class="res-card" id="${
        res.key
      }" style="width: 18rem;" onclick="showRestaurant(this)">
   <img src="${res.val().image}" class="card-img-top">
   <div class="card-body">
     <h5 class="card-title">${res.val().resName}</h5>
     <p class="card-text">Click the card to see their products.</p>
   </div>
 </div>`;
    }
  });

let showRestaurant = (card) => {
  let userId = card.id;
  window.location = "pages/dishes.html#" + userId;
};
