// To control access rights

/*firebase.auth().onAuthStateChanged((user) => {
    if (user) {
      firebase.database().ref(`restaurants/${user.uid}`).once("value", (restaurant) => {
        if (restaurant.val()) {
          window.location = "restaurant.html";
        } else {
          window.location = "../index.html";
        }
      });
    }
  })*/


// Customer class to create Customer objects

class Customer {
  constructor(username, email, phone, country, city, password, image) {
    this.username = username;
    this.email = email;
    this.phone = phone;
    this.country = country;
    this.city = city;
    this.password = password;
    this.image = image;
  }
}

// Restaurant class to create Restaurant objects

class Restaurant {
  constructor(name, email, country, city, password, image) {
    this.name = name;
    this.email = email;
    this.country = country;
    this.city = city;
    this.password = password;
    this.image = image;
  }
}

// To upload image to Firebase Storage and retrieve a URL

let uploadImage = (file) => {
  return new Promise((resolve,
    reject) => {
    var storageRef = firebase.storage().ref();
    // Upload file and metadata to storage
    var uploadTask = storageRef.child('profilePic/' + file.name).put(file);

    // Listen for state changes, errors, and completion of the upload.
    uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED,
      // or 'state_changed'
      (snapshot) => {
        // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
        var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log('Upload is ' + progress + '% done');
        switch (snapshot.state) {
          case firebase.storage.TaskState.PAUSED: // or 'paused'
            console.log('Upload is paused');
            break;
          case firebase.storage.TaskState.RUNNING: // or 'running'
            console.log('Upload is running');
            break;
        }
      },
      (error) => {
        // A full list of error codes is available at
        // https://firebase.google.com/docs/storage/web/handle-errors
        switch (error.code) {
          case 'storage/unauthorized':
            // User doesn't have permission to access the object
            break;
          case 'storage/canceled':
            // User canceled the upload
            break;

          // ...

          case 'storage/unknown':
            // Unknown error occurred, inspect error.serverResponse
            break;
        }
      },
      () => {
        // Upload completed successfully, now we can get the download URL
        uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
          resolve(downloadURL);
      });
    }
  );
  });
};

// To change input boxes

let resName = document.getElementById("res-name");
resName.style.display = "none";
let changeInputBoxes = (userType) => {
let inputs = document.querySelectorAll("input");
let messageDiv = document.getElementById("error-message");
messageDiv.classList.add("d-none");
for (let i = 0; i < inputs.length; i++) {
inputs[i].value = "";
inputs[i].style.borderColor = "#acb1b2";
inputs[i].style.backgroundColor = "#ffffff";
}
if (userType.value === "Customer") {
let username = document.getElementById("username");
let phone = document.getElementById("phone");
resName.style.display = "none";
username.classList.remove("d-none");
phone.classList.remove("d-none");
} else {
let username = document.getElementById("username");
let phone = document.getElementById("phone");
resName.style.display = "block";
username.classList.add("d-none");
phone.classList.add("d-none");
}
};

// To validate user input

let validate = (inputs) => {
let messageDiv = document.getElementById("error-message");
let invalidInput = false;
let regex;
for (let i = 0; i < inputs.length; i++) {
if (inputs[i].id === "res-name") {
regex = /^[.@&]?[a-zA-Z0-9 ]+[ !.@&()]?[ a-zA-Z0-9!()]+/;
} else if (inputs[i].id === "username") {
regex = /^(?=.{3,30}$)[a-z]+(?:['_.\s][a-z]+)*$/gim;
} else if (inputs[i].id === "email") {
regex = /^((?!\.)[\w-_.]*[^.])(@\w+)(\.\w+(\.\w+)?[^.\W])$/gm;
} else if (inputs[i].id === "phone") {
regex = /^([0-9]{11})$/;
} else if (inputs[i].id === "country") {
regex = /^[a-zA-z] ?([a-zA-z]|[a-zA-z] )*[a-zA-z]$/gm;
} else if (inputs[i].id === "city") {
regex = /^[a-zA-z] ?([a-zA-z]|[a-zA-z] )*[a-zA-z]$/gm;
} else if (inputs[i].id === "password") {
regex = /^((?=\S*?[a-zA-Z])(?=\S*?[0-9]).{6,})\S$/;
}
if (inputs[i].id !== "repeat-password" && inputs[i].id !== "picture" && !regex.test(inputs[i].value)) {
invalidInput = true;
} else if (inputs[i].id === "repeat-password") {
if (inputs[i-1].value !== inputs[i].value) {
invalidInput = true;
}
} else if (inputs[i].id === "picture") {
if (inputs[i].files.length === 0) {
invalidInput = true;
} else if (inputs[i].files[0].type.indexOf("image") === -1) {
invalidInput = true;
}
}
if (invalidInput) {
inputs[i].style.borderColor = "#da5b6d";
inputs[i].style.backgroundColor = "#ff8a80";
if (inputs[i].id === "res-name") {
messageDiv.innerHTML = "Invalid name!";
} else if (inputs[i].id === "username") {
messageDiv.innerHTML = "Invalid username!";
} else if (inputs[i].id === "email") {
messageDiv.innerHTML = "Invalid email address!";
} else if (inputs[i].id === "phone") {
messageDiv.innerHTML = "Only 11 digit phone number is accepted!";
} else if (inputs[i].id === "country") {
messageDiv.innerHTML = "Invalid country name!";
} else if (inputs[i].id === "city") {
messageDiv.innerHTML = "Invalid city name!";
} else if (inputs[i].id === "password") {
messageDiv.innerHTML = "Minimum length is 7 with atleast 1 digit!";
} else if (inputs[i].id === "repeat-password") {
messageDiv.innerHTML = "Password doesn't match!";
} else if (inputs[i].id === "picture") {
let userType = document.getElementById("user-type");
if (userType.value === "Customer") {
messageDiv.innerHTML = "You didn't upload a profile picture!"
} else {
messageDiv.innerHTML = "You didn't upload a picture of your restaurant!"
}
}
messageDiv.classList.add("d-block");
messageDiv.classList.remove("d-none");
return false;
}
messageDiv.classList.remove("d-block");
messageDiv.classList.add("d-none");
inputs[i].style.borderColor = "#53a655";
inputs[i].style.backgroundColor = "#baff80";
}
return true;
};

// To register user

let register = async () => {
let inputs;
let userType = document.getElementById("user-type").value;
if (userType === "Customer") {
inputs = document.querySelectorAll(".c-box");
} else {
inputs = document.querySelectorAll(".r-box");
}
let isValid = validate(inputs);
if (!isValid) {
return;
} else {
let username,
resName,
email,
phone,
country,
city,
password,
image;
if (userType === "Customer") {
username = inputs[0];
email = inputs[1];
phone = inputs[2];
country = inputs[3];
city = inputs[4];
password = inputs[5];
file = inputs[7];
} else {
resName = inputs[0];
email = inputs[1];
country = inputs[2];
city = inputs[3];
password = inputs[4];
file = inputs[6];
}
let imageURL = await uploadImage(file.files[0]);
firebase.auth().createUserWithEmailAndPassword(email.value, password.value)
.then((res) => {
if (userType === "Customer") {
let userObj = new Customer(username.value, email.value, phone.value, country.value, city.value, password.value, imageURL);
firebase.database().ref(`users/customers/${res.user.uid}`).set(userObj)
.then(() => {
let messageDiv = document.getElementById("success-message");
messageDiv.innerHTML = "Sign up successful!";
messageDiv.classList.add("d-block");
messageDiv.classList.remove("d-none");
setTimeout(() => {
window.location = "login.html";
}, 1500);
})
} else {
let userObj = new Restaurant(resName.value, email.value, country.value, city.value, password.value, imageURL);
firebase.database().ref(`users/restaurants/${res.user.uid}`).set(userObj)
.then(() => {
let messageDiv = document.getElementById("success-message");
messageDiv.innerHTML = "Sign up successful!";
messageDiv.classList.add("d-block");
messageDiv.classList.remove("d-none");
setTimeout(() => {
window.location = "login.html";
}, 1500);
})
}
})
.catch((err) => {
if (err.message.indexOf("email") !== -1) {
let email = document.getElementById("email");
let messageDiv = document.getElementById("error-message");
email.style.borderColor = "#da5b6d";
email.style.backgroundColor = "#ff8a80";
messageDiv.innerHTML = "This email is already in use by another account!";
messageDiv.classList.add("d-block");
messageDiv.classList.remove("d-none");
}
});
}
};