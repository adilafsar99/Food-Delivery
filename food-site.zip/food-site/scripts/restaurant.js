// To control access rights

firebase.auth().onAuthStateChanged((user) => {
  if (user) {
    firebase
    .database()
    .ref(`users/customers/${user.uid}`)
    .once("value", (user) => {
      if (user.val()) {
        window.location = "../index.html";
      }
      let signupLink = document.getElementById("signup-link");
      let loginLink = document.getElementById("login-link");
      let logoutLink = document.getElementById("logout-link");
      signupLink.classList.add("d-none");
      loginLink.classList.add("d-none");
      logoutLink.classList.remove("d-none");
    });
  } else {
    window.location = "../index.html";
  }
});

let openTab = (evt, tabName) => {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
  firebase.auth().onAuthStateChanged((user) => {
    let order,
    customer,
    dishes,
    status,
    buttonName;
    let currentTab = document.getElementById(tabName);
    currentTab.innerHTML = "";
    firebase.database().ref("orders").on("child_added", (res) => {
      let orderKey = res.key;
      let order = res.val();
      if (order.restaurant === user.uid) {
        firebase.database().ref(`users/customers/${order.customer}`).once("value", (customer) => {})
        .then((customer) => {
          firebase.database().ref(`users/restaurants/${user.uid}/dishes`).once("value", (res) => {
            dishes = res.val();
            for (let key in dishes) {
              if (key === order.dish) {

                if (order.status === "pending") {
                  buttonName = "Accept";
                } else if (order.status === "accepted") {
                  buttonName = "Deliver";
                } else {
                  buttonName = "Remove";
                }
                let method;
                if (tabName === "Pending") {
                  method = `acceptOrder("${orderKey}")`;
                } else if (tabName === "Accepted") {
                  method = `deliverOrder("${orderKey}")`;
                } else {
                  method = `removeOrder("${orderKey}")`;
                }
                let button = `<button onclick=${method} class="mb-2">${buttonName}</button>`;
                if (order.status === tabName.toLowerCase()) {
                  currentTab.innerHTML += `<div class="card mb-2">
                  <div class="card-body">
                  <h5 class="card-title">${tabName}</h5>
                  <p class="card-text">${dishes[key].name}</p>
                  <p class="card-text"><small class="text-muted">${customer.val().username}</small></p>
                  </div>
                  <img src="${dishes[key].image}" class="card-img-bottom">
                  </div><div>${button}</div>`;
                }
                if (currentTab.innerHTML === "") {
                    currentTab.innerHTML = `<div class ="text-center mt-5"><h1>Nothing Here.</h1></div>`;
                  }
              }
            }
          }
          );
        });
      }
    });
  });
};

// To upload image to Firebase Storage and retrieve a URL

let uploadImage = (file) => {
  return new Promise((resolve, reject) => {
    var storageRef = firebase.storage().ref();
    // Upload file and metadata to storage
    var uploadTask = storageRef.child("profilePic/" + file.name).put(file);

    // Listen for state changes, errors, and completion of the upload.
    uploadTask.on(
      firebase.storage.TaskEvent.STATE_CHANGED,
      // or 'state_changed'
      (snapshot) => {
        // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
        var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log("Upload is " + progress + "% done");
        switch (snapshot.state) {
          case firebase.storage.TaskState.PAUSED: // or 'paused'
            console.log("Upload is paused");
            break;
          case firebase.storage.TaskState.RUNNING: // or 'running'
            console.log("Upload is running");
            break;
        }
      },
      (error) => {
        // A full list of error codes is available at
        // https://firebase.google.com/docs/storage/web/handle-errors
        switch (error.code) {
          case "storage/unauthorized":
            // User doesn't have permission to access the object
            break;
          case "storage/canceled":
            // User canceled the upload
            break;

          // ...

          case "storage/unknown":
            // Unknown error occurred, inspect error.serverResponse
            break;
        }
      },
      () => {
        // Upload completed successfully, now we can get the download URL
        uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
          resolve(downloadURL);
      });
    }
  );
  });
};

let addDish = async () => {
let regex;
let invalidInput = false;
let messageDiv = document.getElementById("error-message");
let userInputs = document.querySelectorAll(".validate");
for (let i = 0; i < userInputs.length; i++) {
if (userInputs[i].id === "name") {
regex = /^[a-zA-z] ?([a-zA-z]|[a-zA-z] )*[a-zA-z]$/gm;
} else if (userInputs[i].id === "price") {
regex = /^([0-9]{1,5})$/;
}
if (userInputs[i].id !== "image" && !regex.test(userInputs[i].value)) {
invalidInput = true;
} else if (userInputs[i].id === "image") {
if (userInputs[i].files.length === 0) {
invalidInput = true;
messageDiv.innerHTML = "Please upload a picture for the dish!";
} else if (userInputs[i].files[0].type.indexOf("image") === -1) {
invalidInput = true;
messageDiv.innerHTML = "Please upload an image file!";
}
}
if (userInputs[i].id === "name") {
messageDiv.innerHTML = "Invalid name!";
} else if (userInputs[i].id === "price") {
messageDiv.innerHTML = "Invalid price!";
}
if (invalidInput) {
userInputs[i].style.borderColor = "#da5b6d";
userInputs[i].style.backgroundColor = "#ff8a80";
messageDiv.classList.add("d-block");

messageDiv.classList.remove("d-none");
return;
}
userInputs[i].style.borderColor = "#53a655";
userInputs[i].style.backgroundColor = "#baff80";
messageDiv.classList.remove("d-block");
messageDiv.classList.add("d-none");
}
let name = userInputs[0];
let price = userInputs[1];
let category = document.getElementById("category");
let deliveryType = document.getElementById("delivery-type");
image = await uploadImage(image.files[0]);
let product = {
name: name.value,
price: price.value,
category: category.value,
deliveryType: deliveryType.value,
image: image,
};
firebase.auth().onAuthStateChanged((user) => {
firebase.database().ref(`users/restaurants/${user.uid}/dishes`).push(product);
let modalCloseBtn = document.getElementById("modal-close-btn");
for (let i = 0; i < userInputs.length; i++) {
userInputs[i].value = "";
userInputs[i].style.borderColor = "#acb1b2";
userInputs[i].style.backgroundColor = "#ffffff";
}
category.selectedIndex = 0;
deliveryType.selectedIndex = 0;
modalCloseBtn.click();
});
};

let logOut = () => {
firebase
.auth()
.signOut()
.then(() => {
window.location = "../index.html";
});
};

// To accept order

let acceptOrder = (orderKey) => {
firebase.database().ref(`orders/${orderKey}`).update({
status: "accepted"
});
alert("Order Accepted!");
openTab()
}

// To deliver order

let deliverOrder = (orderKey) => {
firebase.database().ref(`orders/${orderKey}`).update({
status: "delivered"
});
alert("Order Delivered!");
openTab()
}

// To remove order

let removeOrder = (orderKey) => {
firebase.database().ref(`orders/${orderKey}`).update({
status: "removed"
});
alert("Order Removed!");
openTab()
}