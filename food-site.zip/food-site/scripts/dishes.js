// To control access rights

firebase.auth().onAuthStateChanged((user) => {
  if (user) {
    firebase
    .database()
    .ref(`users/restaurants/${user.uid}`)
    .once("value", (user) => {
      if (user.val()) {
        window.location = "restaurant.html";
      }
      let signupLink = document.getElementById("signup-link");
      let loginLink = document.getElementById("login-link");
      let logoutLink = document.getElementById("logout-link");
      signupLink.classList.add("d-none");
      loginLink.classList.add("d-none");
      logoutLink.classList.remove("d-none");
    });
  }
});

let resId = window.location.hash;
resId = resId.slice(1);
firebase.database().ref(`users/restaurants/${resId}/dishes`).on("child_added", (res) => {
  let dishCards = document.getElementById("dishes-cards");
  dishCards.innerHTML += `<div class="card mb-3" style="width: 18rem;">
  <img src="${res.val().image}" class="card-img-top">
  <div class="card-body">
  <h5 class="card-title">${res.val().name}</h5>
  </div>
  <ul class="list-group list-group-flush">
  <li class="list-group-item">Price: ${res.val().price} Rs</li>
  <li class="list-group-item">Delivery: ${res.val().deliveryType}</li>
  <li class="list-group-item">Category: ${res.val().category}</li>
  </ul>
  <div class="card-body">
  <button onclick="placeOrder('${res.key}', '${resId}')">Order Now</button>
  </div>
  </div>`;
});

let placeOrder = (dishId, resId) => {
  firebase.auth().onAuthStateChanged((user) => {
    if (user) {
      let order = {
        customer: user.uid,
        restaurant: resId,
        dish: dishId,
        status: "pending"
      };
      console.log(order)
      firebase.database().ref("orders").push(order).then((res) => {
        alert("Your order has been placed successfully!");
        console.log(res.val())
      });
    }
    else {
      alert("You have to log in first!");
    }
  });
};

let logOut = () => {
  firebase
  .auth()
  .signOut()
  .then(() => {
    let signupLink = document.getElementById("signup-link");
    let loginLink = document.getElementById("login-link");
    let logoutLink = document.getElementById("logout-link");
    signupLink.classList.remove("d-none");
    loginLink.classList.remove("d-none");
    logoutLink.classList.add("d-none");
  });
};
