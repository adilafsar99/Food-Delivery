firebase.auth().onAuthStateChanged((user) => {
  if (user) {
    firebase
    .database()
    .ref(`users/restaurants/${user.uid}`)
    .once("value", (user) => {
      if (user.val()) {
        window.location = "pages/restaurant.html";
      }
      let signupLink = document.getElementById("signup-link");
      let loginLink = document.getElementById("login-link");
      let logoutLink = document.getElementById("logout-link");
      signupLink.classList.add("d-none");
      loginLink.classList.add("d-none");
      logoutLink.classList.remove("d-none");
    });
  }
});

let logOut = () => {
  firebase
  .auth()
  .signOut()
  .then(() => {
    let ordersLink = document.getElementById("orders-link");
    let signupLink = document.getElementById("signup-link");
    let loginLink = document.getElementById("login-link");
    let logoutLink = document.getElementById("logout-link");
    ordersLink.classList.add("d-none");
    signupLink.classList.remove("d-none");
    loginLink.classList.remove("d-none");
    logoutLink.classList.add("d-none");
  });
};

firebase.database().ref(`users/restaurants`).on("child_added", (res) => {
    let resCardsDiv = document.getElementById("restaurant-cards-div");
    resCardsDiv.innerHTML += `<div class="res-card mb-5" id="${
    res.key
    }" style="width: 18rem;" onclick="showRestaurant(this)">
    <img src="${res.val().image}" class="card-img-top" height="100%">
    <div class="card-body">
    <h5 class="card-title">${res.val().name}</h5>
    <p class="card-text">Click the card to see their products.</p>
    </div>
    </div>`;
});

let showRestaurant = (card) => {
  let userId = card.id;
  window.location = "pages/dishes.html#" + userId;
};
